<?php
/**
 * My Library Plugin
 */

// no direct access
defined("_JEXEC") or die("Restricted access");

/**
 * Path to My Library
 */
define("MYLIBRARY_PATH", dirname(__FILE__) . DS . "mylibrary");

/**
 * My file importer. Uses dot separators to define namespaces.
 *
 * @param string $path Path to file to import
 * @return boolean
 */
function myimport($path) {
    return JLoader::import($path, MYLIBRARY_PATH, "mylibrary");
}
