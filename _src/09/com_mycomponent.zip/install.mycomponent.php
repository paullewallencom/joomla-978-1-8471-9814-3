<?php
/**
 * Installation file for My Component
 */

// Don't allow direct linking
defined('_JEXEC') or die('Restricted Access');

/**
 * Installation function for My Component
 */
function com_install() {
    // load language file for install output
    $lang = & JFactory::getLanguage();
    $lang->load('com_mycomponent');
    
    // Get installers, DBO, and path to plugin installation files
    $componentInstaller =& JInstaller::getInstance();
    $installer = new JInstaller();
    $db =& JFactory::getDBO();
    $pathToPlgMylibrary = $componentInstaller->getPath('source') . DS . 'plg_mylibrary';
    
    // get My Library if it is already installed
    $query = 'SELECT COUNT(*)' 
           . ' FROM ' . $db->nameQuote('#__plugins')
           . ' WHERE ' . $db->nameQuote('element') . ' = ' . $db->Quote('mylibrary')
           . ' AND ' .   $db->nameQuote('folder')  . ' = ' . $db->Quote('library');
    $db->setQuery($query);
    $myLibraryInstalled = (bool)$db->loadResult();

    // work out what to do now
    if ($myLibraryInstalled) {
        // already installed
        echo '<p>'.JText::_('REQUIRED PLUGIN MY LIBRARY ALREADY INSTALLED').'</p>';
    } else {
        // Install the plugin My Library
        if (!$installer->install($pathToPlgMylibrary)) {
            echo '<p>'.JText::_('FAILED TO INSTALL REQUIRED PLUGIN MY LIBRARY').'</p>';
        } else {
            echo '<p>'.JText::_('INSTALLED REQUIRED PLUGIN MY LIBRARY').'</p>';
        }
    }
    
    // publish My Library
    $query = 'UPDATE ' . $db->nameQuote('#__plugins')
           . ' SET ' . $db->nameQuote('published') . ' = 1'
           . ' WHERE ' . $db->nameQuote('element') . ' = ' . $db->Quote('mylibrary')
           . ' AND ' .   $db->nameQuote('folder')  . ' = ' . $db->Quote('library');
    $db->setQuery($query);
    if (!$db->query()) {
        echo '<p>'.JText::_('FAILED TO ENABLE REQUIRED PLUGIN MY LIBRARY').'</p>';
    } else {
        echo '<p>'.JText::_('ENABLED REQUIRED PLUGIN MY LIBRARY').'</p>';
    }
    
    // all done!
    return true;
}

?>
