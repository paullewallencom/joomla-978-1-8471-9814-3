<?php
/**
 * Un-Install file for My Component
 */

// Don't allow direct linking
defined('_JEXEC') or die('Restricted Access');

function com_uninstall() {
	
}

?>
