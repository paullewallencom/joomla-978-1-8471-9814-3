<?php
/**
 * My Class
 */

// no direct access
defined("_JEXEC") or die("Restricted access");

/**
 * MyClass
 *
 * @package mylibrary
 */
class MyClass {
}
